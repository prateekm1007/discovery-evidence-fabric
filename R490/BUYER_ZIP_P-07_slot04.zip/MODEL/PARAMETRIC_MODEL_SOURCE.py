"""PARAMETRIC MODEL SOURCE — package P-07 (tpl:P07_drainage_floor_dual_lumen:v1).
THE SOURCE OF TRUTH for this 3D design: this build program plus
MODEL/PARAMETERS.json. STEP/STL/GLB/SVG are derived artifacts.
Executed in the engine's deterministic sandbox (discovery_fabric.engine.cad_pipeline._execute_build_program):
only cq/math + min/max/abs/len/range/float/int/round/sorted are
available; every dimension must come from p[...].
program_source_sha256: da005217c9e3429d36ec7decd5ff08a6c7d45b2f9b82fef6643c27fde4514488
"""

def build(p):
    od = p["outer_diameter_mm"]
    pd = p["primary_lumen_diameter_mm"]
    fd = p["floor_lumen_diameter_mm"]
    fo = p["floor_offset_mm"]
    L = p["length_mm"]
    body = cq.Workplane("XY").circle(od * 0.5).extrude(L)
    prim = (cq.Workplane("XY").center(pd * 0.35, 0.0)
            .circle(pd * 0.5).extrude(L))
    floor = (cq.Workplane("XY").center(-fo, 0.0)
             .circle(fd * 0.5).extrude(L))
    part = body.cut(prim).cut(floor)
    return {"dual_lumen_catheter": part}
