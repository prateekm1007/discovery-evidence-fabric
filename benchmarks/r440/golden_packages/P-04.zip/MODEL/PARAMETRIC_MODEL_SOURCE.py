"""PARAMETRIC MODEL SOURCE — package P-04 (tpl:P04_contact_time_catheter:v1).
THE SOURCE OF TRUTH for this 3D design: this build program plus
MODEL/PARAMETERS.json. STEP/STL/GLB/SVG are derived artifacts.
Executed in the engine's deterministic sandbox (discovery_fabric.engine.cad_pipeline._execute_build_program):
only cq/math + min/max/abs/len/range/float/int/round/sorted are
available; every dimension must come from p[...].
program_source_sha256: 3b2548c5cea1e32f2f0625dd8eb29b2cdb39dfad16a646daf7b5d3db9fc0ee52
"""

def build(p):
    od = p["outer_diameter_mm"]
    ld = p["lumen_diameter_mm"]
    L = p["length_mm"]
    ct = p["enzyme_coating_thickness_mm"]
    body = (cq.Workplane("XY").circle(od * 0.5).circle(ld * 0.5)
            .extrude(L))
    coating = (cq.Workplane("XY")
               .circle(ld * 0.5 + ct * 0.1)
               .circle(ld * 0.5 - ct).extrude(L))
    return {"catheter_body": body, "enzyme_coating_layer": coating}
